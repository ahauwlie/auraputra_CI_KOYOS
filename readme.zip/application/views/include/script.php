<script src="<?php echo base_url('/inti/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/jquery.viewport.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/jQuerySimpleCounter.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/jquery.magnific-popup.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/isotope.pkgd.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/animsition.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/rellax.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/swiper.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/smoothscroll.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/svg4everybody.legacy.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/TweenMax.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/TimelineLite.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/typed.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/vivus.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/theme.js'); ?>"></script>
<script data-cfasync="false" src="<?php echo base_url('/inti/js/email-decode.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/polyfill.min.js'); ?>"></script>